/***////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////***/
/**
 * Space Invaders Reboot:
 * 
 * Author: Matt Fung
 * Development: June - July 2019
 * Language: JavaScript (ES6)
 */
/***////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////***/
/* Use Strict */
"use strict";

/* Global */
let ctx;

/* Images */
let img_player = new Image(),
    img_lazer = new Image(),
    img_special_lazer = new Image(),
    img_missile = new Image(),
    img_shield = new Image(),
    img_explosion = new Image(),
    img_background = new Image(),
    img_type_1 = new Image(),
    img_type_2 = new Image(),
    img_type_3 = new Image(),
    img_type_4 = new Image(),
    img_type_5 = new Image(),
    img_enemy_lazer = new Image(),
    img_boss = new Image(),
    img_boss_lazer = new Image();

/* Player Sprites */
img_player.src = "spaceship.png";
img_lazer.src = "lazer_red.png";
img_special_lazer.src = "lazer_yellow.png";
img_missile.src = "rocket.png";
img_shield.src = "shield.png";

/* Enemy Sprites */
img_type_1.src = "type_1.png";
img_type_2.src = "type_2.png";
img_type_3.src = "type_3.png";
img_type_4.src = "type_4.png";
img_type_5.src = "type_5.png";
img_enemy_lazer.src = "lazer_green.png";

/* Boss Sprites */
img_boss.src = "boss.png";
img_boss_lazer.src = "lazer_blue.png";

/* Gamepage Sprites */
img_explosion.src = "explosion.png";
img_background.src = "vertical_background.png";

/* Player Globals */
let my_player,
    players_list = new Array(),
    shooting_interval = 300;

/* Projectile Globals */
let player_projectile,
    projectiles_list = new Array(),
    special_counter = 0,
    special_fire_interval;

/* Shield Globals */
let player_shield,
    shield_list = new Array();

/* Enemy Globals */
let my_enemy,
    enemies_list = new Array(),
    spawn_wave,
    type_4_5_flag = false;

/* Enemy Projectile Globals */
let enemy_projectile,
    enemy_projectiles_list = new Array();

/* Explosion Globals */
let collision_explosion,
    explosion_list = new Array();

/* Enemy Type 1 */
let type_1_can_gen = false,
    type_1_gen_interval = 1000;

// /* Enemy Type 2 */
let type_2_can_gen = false,
    type_2_gen_interval = 1000;

/* Enemy Type 3 */
let type_3_can_gen = false,
    type_3_gen_interval = 1000;

/* Enemy Type 4 */
let type_4_can_gen = false,
    type_4_gen_interval = 1000;

/* Enemy Type 5 */
let type_5_can_gen = false,
    type_5_gen_interval = 1000;

/* Enemy Boss */
let type_boss_can_gen = false,
    type_boss_gen_interval = 1000,
    health_check_1 = false,
    health_check_2 = false,
    shot_counter = 0;

/* Background Globals */
let background_width = 500,
    background_height = 850,
    background_x = 0,
    background_y = 0,
    distance_y = 0.75,
    img_width,
    img_height;

/* Block Globals */
let popup_title,
    popup_gameover,
    popup_youwin,
    popup_dev_name;

/* Canvas Surface Globals */
let canvas_surface = {
    canvas: document.createElement("canvas"),
    initialize_game: function () {
        this.canvas.width = 500;
        this.canvas.height = 850;
        this.canvas.style.display = 'inline-block';
        this.canvas.style.position = 'relative';
        this.canvas.id = "canvas-container";
        document.getElementById("div-container").appendChild(canvas_surface.canvas);
        this.context = this.canvas.getContext("2d");
        this.interval = setInterval(update_canvas, 20);
        window.addEventListener('keydown', function (event) {
            canvas_surface.keys = (canvas_surface.keys || []);
            canvas_surface.keys[event.keyCode] = (event.type == "keydown");
        })
        window.addEventListener('keyup', function (event) {
            canvas_surface.keys[event.keyCode] = (event.type == "keydown");
        })
        window.addEventListener("keydown", function (event) {
            if ([32, 37, 38, 39, 40].indexOf(event.keyCode) > -1) {
                event.preventDefault();
            }
        }, false);
    },
    reset_canvas: function () {
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    },
    stop_canvas: function() {
        clearInterval(this.interval);
    }
};

/* Queue Implementation */
class Queue 
{
    constructor() 
    {
        this.queued_items = new Array();
    }

    enqueue(element_in) 
    {
        this.queued_items.push(element_in);
    }
    
    dequeue() 
    {
        if (this.is_empty())
            return "Error";
        return this.queued_items.shift();
    }
    front() 
    {
        if (this.is_empty())
            return "No elements in Queue";
        return this.queued_items[0];
    } 
    is_empty() 
    {
        return this.queued_items.length == 0;
    }
    output_queue() 
    {
        let output;
        for (let i = 0; i < this.queued_items.length; i++)
            output += this.queued_items[i] + " ";
        return output;
    }
    len()
    {
        return this.queued_items.length;
    }
}

/* Queue */
let enemy_spawning_queue = new Queue(),
    current_wave,
    flag_spawn_wave = false,
    num_spawned = 0;

/***////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////***/

function create_player(width, height, x, y) 
{
    this.location = canvas_surface;
    this.width = width;
    this.height = height;
    this.x_speed = 0;
    this.y_speed = 0;
    this.friction = 0.93;
    this.x_pos = x;
    this.y_pos = y;
    this.health = 200;
    this.can_fire = true;
    this.missile = true;
    this.special_fire = true;
    this.rapid_fire = false;
    this.shield = true;
    this.health_bar = function() {
        ctx.fillStyle = "Chartreuse";
        ctx.fillRect(this.x_pos + 20, this.y_pos + 44, 30 * (this.health / 200), 3);
    }
    this.weapons_online = function() {
        if (this.special_fire)
        {
            ctx.fillStyle = "Gold";
            ctx.fillRect(this.x_pos + 10, this.y_pos + 44, 3, 3);
        }
        else
        {
            // ctx.fillStyle = "FireBrick";
            ctx.fillStyle = "Red";
            ctx.fillRect(this.x_pos + 10, this.y_pos + 44, 3, 3);
        }
        if (this.missile)
        {
            ctx.fillStyle = "DodgerBlue";
            ctx.fillRect(this.x_pos, this.y_pos + 44, 3, 3);
        }
        else
        {
            // ctx.fillStyle = "FireBrick";
            ctx.fillStyle = "Red";
            ctx.fillRect(this.x_pos, this.y_pos + 44, 3, 3);
        }
    }
    this.update_speed = function () {
        this.x_pos += this.x_speed;
        this.y_pos += this.y_speed;
        check_bounds();
    }   
    this.update_movement = function() {
        ctx = canvas_surface.context;
        ctx.drawImage(img_player, this.x_pos, this.y_pos);
    } 
}

function create_shield(width, height, x, y)
{
    this.location = canvas_surface;
    this.width = width;
    this.height = height;
    this.x_pos = x;
    this.y_pos = y;
    this.health = 100;
    this.visible = false;
    this.update_speed = function () {
        this.x_pos = players_list[0].x_pos - 12.5;
        this.y_pos = players_list[0].y_pos - 20;
    }
    this.update_movement = function () {
        ctx = canvas_surface.context;
        ctx.drawImage(img_shield, this.x_pos, this.y_pos);
    } 
}

function create_enemy(width, height, x, y, type, current_speed_x, current_speed_y, img_type, rapid_fire, fire_rate, multi_rate, health, boss)
{
    this.location = canvas_surface;
    this.width = width;
    this.height = height;
    this.x_speed = 0;
    this.y_speed = 0;
    this.current_speed_x = current_speed_x;
    this.current_speed_y = current_speed_y;
    this.x_pos = x;
    this.y_pos = y;
    this.health = health;
    this.health_bar_constant = health;
    this.boss = boss;
    this.can_fire = true;
    this.alternate_fire = false;
    this.rapid_fire = rapid_fire;
    this.fire_rate = fire_rate;
    this.multi_rate = multi_rate;
    this.type = type
    this.health_bar = function () {
        ctx.fillStyle = "Chartreuse";
        ctx.fillRect(this.x_pos + this.width * 0.25, this.y_pos - 5, (this.width / 2) * (this.health / this.health_bar_constant), 3);
    }
    this.update_speed = function () {
        this.x_pos += this.x_speed;
        this.y_pos += this.y_speed;
    }
    this.update_movement = function () {
        ctx = canvas_surface.context;
        ctx.drawImage(img_type, this.x_pos, this.y_pos);
    }
}

function create_projectile(width, height, x, y, img_type, x_speed, damage)
{
    this.location = canvas_surface;
    this.width = width;
    this.height = height;
    this.x_speed = x_speed;
    this.y_speed = 0;
    this.x_pos = x;
    this.y_pos = y;
    this.damage = damage;
    this.update_speed = function () {
        this.x_pos += this.x_speed;
        this.y_pos += this.y_speed;
    }
    this.update_movement = function () {
        ctx = canvas_surface.context;
        ctx.drawImage(img_type, this.x_pos, this.y_pos);
    }
}

function create_explosion(width, height, x, y, img_type, y_speed)
{
    this.location = canvas_surface;
    this.width = width;
    this.height = height;
    this.x_speed = 0;
    this.y_speed = y_speed;
    this.x_pos = x;
    this.y_pos = y;
    this.distance_tracker = 0;
    this.update_speed = function () {
        this.x_pos += this.x_speed;
        this.y_pos += this.y_speed;
    }
    this.update_movement = function () {
        ctx = canvas_surface.context;
        ctx.drawImage(img_type, this.x_pos, this.y_pos);
    }
}

function create_wave(enemy_type, num_enemy)
{
    this.enemy_type = enemy_type;
    this.num_enemy = num_enemy;
}

/***////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////***/

function page_loadup()
{
    popup_title = document.getElementById("popup-startup");
    popup_title.style.display = "block"; 
    popup_gameover = document.getElementById("popup-gameover");
    popup_gameover.style.display = "none";
    popup_youwin = document.getElementById("popup-you-win");
    popup_youwin.style.display = "none";
    popup_dev_name = document.getElementById("popup-developer-name");
    popup_dev_name.style.display = "none";

    // Queue up enemy waves
    queue_enemy_waves();

    current_wave = enemy_spawning_queue.dequeue();
    // console.log(current_wave.num_enemy);
    // console.log(enemy_spawning_queue.front().enemy_type);
}

function onload_setup() 
{
    // Play sound
    let menu_sound = new create_sound("click.wav");
    menu_sound.play();

    // Get rid of block
    popup_title.style.display = "none";

    // Enable block
    popup_dev_name.style.display = "block";

    // Set the backgrounds height and width
    img_width = img_background.width;
    img_height = img_background.height;

    // Initialize and setup the canvas surface
    canvas_surface.initialize_game();

    // Create a player
    my_player = new create_player(50, 45, 228, 770);

    // Keep track of the player
    players_list.push(my_player);

    // Check to see how many players are in the game
    console.log(players_list);

    // Create a shield
    player_shield = new create_shield(76, 20, my_player.x_pos - 12.5, my_player.y_pos - 20);

    // Keep track of the player's shield
    shield_list.push(player_shield);

    // Check to see how shields are in the game
    console.log(shield_list);

    // Spawn first wave
    setTimeout(function () {
        activate_enemy_type(current_wave.enemy_type);
    }, 3000);
}

function update_canvas() 
{
    // Clear the canvas for each animation
    canvas_surface.reset_canvas();

    // Allow enemy spawning
    generate_enemy();

    // Check if next wave of enemies can be spawned
    to_next_wave();

    // Draw background
    draw_background();

    /* Testing purposes only */
    // stop_generate(spawn_wave);

    for (let play_i = 0; play_i < players_list.length; play_i++) 
    {
        // Allow player to move
        player_movement(play_i);

        // Allow player to shoot
        player_shoot(play_i);

        // Allow player to shield
        player_shielding(play_i);

        // Check player collision with enemy
        if (!player_collision(play_i)) {
            // Update the player's movement
            players_list[play_i].update_movement();
        }

        // Update the player's health
        players_list[play_i].health_bar();

        // Update the player's weapon systems
        players_list[play_i].weapons_online();

        // Update the player's speed
        players_list[play_i].update_speed();
    }

    for (let en_i = 0; en_i < enemies_list.length; en_i++) 
    {
        enemy_movement(en_i);
        enemies_list[en_i].update_movement();
        enemies_list[en_i].health_bar();
        enemies_list[en_i].update_speed();
    }

    for (let en_proj_i = 0; en_proj_i < enemy_projectiles_list.length; en_proj_i++)
    {
        enemy_projectiles_list[en_proj_i].y_speed = 15;
        enemy_projectiles_list[en_proj_i].update_speed();
        
        hit_shield(en_proj_i);
        hit_player(en_proj_i);

        if (!enemy_projectile_collision(en_proj_i))
            enemy_projectiles_list[en_proj_i].update_movement();
    }

    for (let proj_i = 0; proj_i < projectiles_list.length; proj_i++)
    {
        projectiles_list[proj_i].y_speed = -15;
        projectiles_list[proj_i].update_speed();

        hit_enemy(proj_i);
        
        if (!projectile_collision(proj_i))
            projectiles_list[proj_i].update_movement();
    }

    for (let ex_i = 0; ex_i < explosion_list.length; ex_i++)
    {
        explosion_list[ex_i].update_speed();
        explosion_list[ex_i].distance_tracker++;
        if (!explosion_bounds(ex_i))
            explosion_list[ex_i].update_movement();
    }
}

function draw_background()
{
    ctx = canvas_surface.context;

    if (img_height <= background_height)
    {
        if (background_y > background_height)
        {
            background_y += -img_height;
        }
        if (background_y > 0)
        {
            ctx.drawImage(img_background, background_x, -img_height + background_y, img_width, img_height);
        }
        if (background_y - img_height > 0)
        {
            ctx.drawImage(img_background, background_x, -img_height * 2 + background_y, img_width, img_height);
        }
    }
    else 
    {
        if (background_y > background_height)
        {
            background_y = background_height - img_height;
        }
        if (background_y > (background_height - img_height))
        {
            ctx.drawImage(img_background, background_x, background_y - img_height + 1, img_width, img_height);
        }
    }

    ctx.drawImage(img_background, background_x, background_y, img_width, img_height);
    background_y += distance_y;
}

function generate_enemy() 
{
    if (num_spawned < current_wave.num_enemy)
    {
        if (type_1_can_gen)
        {
            type_1_can_gen = false;

            // Type 1 generation
            my_enemy = new create_enemy(45, 58, 227.5, -58, 1, -2, 0, img_type_1, true, 2000, 200, 150, false);
            enemies_list.push(my_enemy);
            
            num_spawned++;

            console.log(enemies_list);

            setTimeout(function() 
            {
                type_1_can_gen = true;
            }, type_1_gen_interval);
        }

        if (type_2_can_gen)
        {
            type_2_can_gen = false;

            // Type 2 generation
            my_enemy = new create_enemy(45, 59, 500, -58, 2, -2, 0, img_type_2, false, 2000, 200, 200, false);
            enemies_list.push(my_enemy);

            num_spawned++;
            
            console.log(enemies_list);

            setTimeout(function() 
            {
                type_2_can_gen = true;
            }, type_2_gen_interval);
        }

        if (type_3_can_gen)
        {
            type_3_can_gen = false;

            // Type 3 generation
            my_enemy = new create_enemy(50, 45, 450, -45, 3, 0, 3, img_type_3, true, 2000, 200, 100, false);
            enemies_list.push(my_enemy);

            num_spawned++;
            
            console.log(enemies_list);

            setTimeout(function() 
            {
                type_3_can_gen = true;
            }, type_3_gen_interval);
        }

        if (type_4_can_gen)
        {
            type_4_can_gen = false;

            // Type 4 generation
            my_enemy = new create_enemy(64, 32, 0, -58, 4, 0, 3, img_type_4, true, 1000, 150, 250, false);
            enemies_list.push(my_enemy);

            num_spawned++;
            
            console.log(enemies_list);

            setTimeout(function() 
            {
                type_4_can_gen = true;
            }, type_4_gen_interval);
        }

        if (type_5_can_gen)
        {
            type_5_can_gen = false;

            // Type 5 generation
            my_enemy = new create_enemy(64, 32, 440, -58, 5, 0, 3, img_type_5, true, 500, 100, 250, false);
            enemies_list.push(my_enemy);

            num_spawned++;
            
            console.log(enemies_list);

            setTimeout(function() 
            {
                type_5_can_gen = true;
            }, type_5_gen_interval);
        }

        if (type_boss_can_gen)
        {
            type_boss_can_gen = false;

            // Type boss generation
            my_enemy = new create_enemy(95, 65, 202.5, -80, 6, 0, 2, img_boss, true, 1500, 100, 8000, true);
            enemies_list.push(my_enemy);

            num_spawned++;

            console.log(enemies_list);

            setTimeout(function()
            {
                type_boss_can_gen = false;
            }, type_boss_gen_interval)
        }
    }
}

function queue_enemy_waves()
{
    enemy_spawning_queue.enqueue(new create_wave(3, 3));
    enemy_spawning_queue.enqueue(new create_wave(3, 6));
    enemy_spawning_queue.enqueue(new create_wave(2, 6));
    enemy_spawning_queue.enqueue(new create_wave(4, 4));
    enemy_spawning_queue.enqueue(new create_wave(2, 6));
    enemy_spawning_queue.enqueue(new create_wave(5, 4));
    enemy_spawning_queue.enqueue(new create_wave(5, 4));
    enemy_spawning_queue.enqueue(new create_wave(1, 8));
    enemy_spawning_queue.enqueue(new create_wave(2, 8));
    enemy_spawning_queue.enqueue(new create_wave(3, 8));
    enemy_spawning_queue.enqueue(new create_wave(1, 8));
    enemy_spawning_queue.enqueue(new create_wave(6, 1));
}

function to_next_wave() 
{
    if (num_spawned == current_wave.num_enemy && enemies_list.length == 0 && !flag_spawn_wave)
    {
        deactivate_enemy_type(current_wave.enemy_type);
        flag_spawn_wave = true;
        setTimeout(function() {
            num_spawned = 0;
            if (enemy_spawning_queue.len() > 0)
            {
                current_wave = enemy_spawning_queue.dequeue();
                activate_enemy_type(current_wave.enemy_type);
                flag_spawn_wave = false;
            }
            else
            {
                setTimeout(function () {
                    canvas_surface.stop_canvas();
                    let retrieve_element = document.getElementById("canvas-container");
                    retrieve_element.parentNode.removeChild(retrieve_element);
                    popup_youwin.style.display = "block";

                    // Play sound
                    let victory_sound = new create_sound("win1.wav");
                    victory_sound.play();

                    popup_dev_name.style.display = "none";
                }, 1200);
            }
        }, 3000);
    }
}

function activate_enemy_type(type_in)
{
    switch(type_in)
    {
        case 1:
            type_1_can_gen = true;
            break;
        case 2:
            type_2_can_gen = true;
            break;
        case 3:
            type_3_can_gen = true;
            break;
        case 4:
            type_4_can_gen = true;
            break;
        case 5:
            type_5_can_gen = true;
            break;
        case 6:
            type_boss_can_gen = true;
            break;
    }
}

function deactivate_enemy_type(type_in)
{
    switch(type_in)
    {
        case 1:
            type_1_can_gen = false;
            break;
        case 2:
            type_2_can_gen = false;
            break;
        case 3:
            type_3_can_gen = false;
            break;
        case 4:
            type_4_can_gen = false;
            break;
        case 5:
            type_5_can_gen = false;
            break;
        case 6:
            type_boss_can_gen = false;
            break;
    }
}

function create_sound(src) 
{
    this.sound = document.createElement("audio");
    this.sound.src = src;
    this.sound.setAttribute("preload", "auto");
    this.sound.setAttribute("controls", "none");
    this.sound.style.display = "none";
    document.body.appendChild(this.sound);
    this.play = function () {
        this.sound.play();
    }
}

/***////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////***/

function player_movement(play_i)
{
    // Add friction to the horizonal movement of the player
    players_list[play_i].x_speed *= players_list[play_i].friction;

    // Reset the vertical movement of the player
    players_list[play_i].y_speed = 0;

    // On keypress, change the speed of the player
    if (canvas_surface.keys && canvas_surface.keys[37]) {
        players_list[play_i].x_speed = -10;
    }
    if (canvas_surface.keys && canvas_surface.keys[39]) {
        players_list[play_i].x_speed = 10;
    }
    if (canvas_surface.keys && canvas_surface.keys[38]) {
        players_list[play_i].y_speed = -10;
    }
    if (canvas_surface.keys && canvas_surface.keys[40]) {
        players_list[play_i].y_speed = 10;
    }
}

function player_shoot(play_i)
{
    ctx = canvas_surface.context;

    if (special_counter >= 5)
    {
        clearInterval(special_fire_interval);
    }

    if (players_list[play_i].can_fire) 
    {
        if (canvas_surface.keys && canvas_surface.keys[32]) 
        {
            players_list[play_i].can_fire = false;

            // Play sound
            let can_fire_sound = new create_sound("lasergun1.wav");
            can_fire_sound.play();

            player_projectile = new create_projectile(8, 32, players_list[play_i].x_pos + 21, players_list[play_i].y_pos - 10, img_lazer, 0, 20);
            projectiles_list.push(player_projectile);

            console.log(projectiles_list);

            setTimeout(function() 
            {
                players_list[play_i].can_fire = true;
            }, shooting_interval);
        }
    }

    if (players_list[play_i].rapid_fire) 
    {
        if (canvas_surface.keys && canvas_surface.keys[32]) 
        {
            players_list[play_i].rapid_fire = false;

            // // Play sound
            // let can_fire_sound = new create_sound("cannon.wav");
            // can_fire_sound.play();

            player_projectile = new create_projectile(8, 32, players_list[play_i].x_pos + 21, players_list[play_i].y_pos - 10, img_lazer, 0, 15);
            projectiles_list.push(player_projectile);
            player_projectile = new create_projectile(8, 32, players_list[play_i].x_pos + 21, players_list[play_i].y_pos - 10, img_lazer, -2.5, 15);
            projectiles_list.push(player_projectile);
            player_projectile = new create_projectile(8, 32, players_list[play_i].x_pos + 21, players_list[play_i].y_pos - 10, img_lazer, 2.5, 15);
            projectiles_list.push(player_projectile);

            console.log(projectiles_list);

            setTimeout(function() 
            {
                players_list[play_i].rapid_fire = true;
            }, shooting_interval);
        }
    }

    if (players_list[play_i].special_fire)
    {
        if (canvas_surface.keys && canvas_surface.keys[88])
        {
            players_list[play_i].special_fire = false;

            // Play sound
            let multi_fire_sound = new create_sound("cannon.wav");
            multi_fire_sound.play();

            special_fire_interval = setInterval(function() 
            {
                player_projectile = new create_projectile(8, 32, players_list[play_i].x_pos + 21, players_list[play_i].y_pos - 10, img_special_lazer, 1, 40);
                projectiles_list.push(player_projectile);

                player_projectile = new create_projectile(8, 32, players_list[play_i].x_pos + 21, players_list[play_i].y_pos - 10, img_special_lazer, -1, 40);
                projectiles_list.push(player_projectile);

                player_projectile = new create_projectile(8, 32, players_list[play_i].x_pos + 21, players_list[play_i].y_pos - 10, img_special_lazer, 2, 40);
                projectiles_list.push(player_projectile);

                player_projectile = new create_projectile(8, 32, players_list[play_i].x_pos + 21, players_list[play_i].y_pos - 10, img_special_lazer, -2, 40);
                projectiles_list.push(player_projectile);

                player_projectile = new create_projectile(8, 32, players_list[play_i].x_pos + 21, players_list[play_i].y_pos - 10, img_special_lazer, 3, 40);
                projectiles_list.push(player_projectile);

                player_projectile = new create_projectile(8, 32, players_list[play_i].x_pos + 21, players_list[play_i].y_pos - 10, img_special_lazer, -3, 40);
                projectiles_list.push(player_projectile);

                player_projectile = new create_projectile(8, 32, players_list[play_i].x_pos + 21, players_list[play_i].y_pos - 10, img_special_lazer, 0, 40);
                projectiles_list.push(player_projectile);

                special_counter++;

            }, 100);

            setTimeout(function() 
            {
                players_list[play_i].special_fire = true;
                special_counter = 0;
            }, 15000);
        }
    }

    if (players_list[play_i].missile)
    {
        if (canvas_surface.keys && canvas_surface.keys[90])
        {
            players_list[play_i].missile = false;

            // Play sound
            let missile_sound = new create_sound("boomshot.wav");
            missile_sound.play();

            player_projectile = new create_projectile(32, 32, players_list[play_i].x_pos - 10, players_list[play_i].y_pos - 10, img_missile, 0, 35);
            projectiles_list.push(player_projectile);

            player_projectile = new create_projectile(32, 32, players_list[play_i].x_pos + 30, players_list[play_i].y_pos - 10, img_missile, 0, 35);
            projectiles_list.push(player_projectile);

            console.log(projectiles_list);

            setTimeout(function() 
            {
                players_list[play_i].missile = true;
            }, 5000);
        }
    }
}

function player_shielding(play_i)
{
    if (players_list[play_i].shield) {
        if (canvas_surface.keys && canvas_surface.keys[67]) {
            shield_list[0].visible = true;
            shield_list[0].update_speed();
            shield_list[0].update_movement();
            // console.log("shield is active " + shield_list[0].visible);
        }
        else
        {
            shield_list[0].visible = false;
            // console.log("shield is active " + shield_list[0].visible);
        }
    }
}

function enemy_movement(en_i)
{
    switch (enemies_list[en_i].type)
    {
        case 1:
            enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
            enemies_list[en_i].y_speed = enemies_list[en_i].current_speed_y;

            if (enemies_list[en_i].y_pos < 50) 
            {
                enemies_list[en_i].current_speed_y = 1;
            }
            if (enemies_list[en_i].y_pos == 50)
            {
                enemies_list[en_i].y_pos += 2;
                enemies_list[en_i].current_speed_y = 0;
            }
            if (enemies_list[en_i].y_pos > 50)
            {
                enemy_shoot(en_i);
                if (enemies_list[en_i].x_pos > 0 && enemies_list[en_i].x_pos < 455) {
                    enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                }

                if (enemies_list[en_i].x_pos <= 0) {
                    enemies_list[en_i].current_speed_x *= -1;
                    enemies_list[en_i].current_speed_y = 1;
                    enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                    enemies_list[en_i].y_speed = enemies_list[en_i].current_speed_y;
                }

                if (enemies_list[en_i].x_pos >= 455) {
                    enemies_list[en_i].current_speed_x *= -1;
                    enemies_list[en_i].current_speed_y = 1;
                    enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                    enemies_list[en_i].y_speed = enemies_list[en_i].current_speed_y;
                }

                if (enemies_list[en_i].y_pos >= 70) {
                    enemies_list[en_i].current_speed_y *= -1;
                    enemies_list[en_i].y_speed = enemies_list[en_i].current_speed_y;
                }

                if (enemies_list[en_i].y_pos <= 51) {
                    enemies_list[en_i].current_speed_y *= -1;
                    enemies_list[en_i].y_speed = enemies_list[en_i].current_speed_y;
                }
            }
            break;

        case 2:
            enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
            enemies_list[en_i].y_speed = enemies_list[en_i].current_speed_y;

            if (enemies_list[en_i].y_pos < 50) 
            {
                enemies_list[en_i].current_speed_y = 1;
            }
            if (enemies_list[en_i].y_pos == 50)
            {
                enemies_list[en_i].y_pos += 2;
                enemies_list[en_i].current_speed_y = 0;
            }

            if (enemies_list[en_i].y_pos > 50) 
            {
                enemy_shoot(en_i);
                if (enemies_list[en_i].x_pos > 0 && enemies_list[en_i].x_pos < 455) 
                {
                    enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                }

                if (enemies_list[en_i].x_pos <= 0) 
                {
                    enemies_list[en_i].current_speed_x = 2;
                    enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                    enemies_list[en_i].y_speed = enemies_list[en_i].current_speed_y;
                }

                if (enemies_list[en_i].x_pos >= 455) 
                {
                    enemies_list[en_i].current_speed_x = -2;
                    enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                    enemies_list[en_i].y_speed = enemies_list[en_i].current_speed_y;
                }
            }
            break;

        case 3:
            enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
            enemies_list[en_i].y_speed = enemies_list[en_i].current_speed_y;

            if (enemies_list[en_i].y_pos >= 50 && enemies_list[en_i].y_pos < 55)
            {
                enemies_list[en_i].y_pos += 5;
                enemies_list[en_i].current_speed_x = -2;
                enemies_list[en_i].current_speed_y = 0;
            }

            if (enemies_list[en_i].y_pos >= 55)
            {
                enemy_shoot(en_i);
                if (enemies_list[en_i].x_pos <= 0) 
                {
                    enemies_list[en_i].current_speed_x = 2;
                    enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                }

                if (enemies_list[en_i].x_pos >= 455) 
                {
                    enemies_list[en_i].current_speed_x = -2;
                    enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                }
            }
            break;

        case 4:
            enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
            enemies_list[en_i].y_speed = enemies_list[en_i].current_speed_y;

            if (enemies_list[en_i].y_pos >= 50 && enemies_list[en_i].y_pos < 55)
            {
                enemies_list[en_i].y_pos += 5;
                enemies_list[en_i].current_speed_x = 2;
                enemies_list[en_i].current_speed_y = 0;
            }

            if (enemies_list.length >= 4)
            {
                // type_4_5_flag = stop_generate_type_4_5(spawn_wave);

                if (enemies_list[0].x_pos >= 400)
                {
                    // enemy_shoot(en_i);
                    enemies_list[en_i].current_speed_x = 0;
                }
            }
            // if (type_4_5_flag)
            // {
                enemy_shoot(en_i);
            // }

            if (enemies_list.length < 4)
            {
                if (enemies_list[en_i].y_pos >= 55) 
                {
                    if (enemies_list[en_i].x_pos <= 0) 
                    {
                        enemies_list[en_i].current_speed_x = 2;
                        enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                    }

                    if (enemies_list[en_i].x_pos >= 455) 
                    {
                        enemies_list[en_i].current_speed_x = -2;
                        enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                    }
                }
            }
            break;

        case 5:
            enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
            enemies_list[en_i].y_speed = enemies_list[en_i].current_speed_y;

            if (enemies_list[en_i].y_pos >= 60 && enemies_list[en_i].y_pos < 70)
            {
                enemies_list[en_i].y_pos += 5;
                enemies_list[en_i].current_speed_x = -2;
                enemies_list[en_i].current_speed_y = 0;
            }

            if (enemies_list.length >= 4)
            {
                // type_4_5_flag = stop_generate_type_4_5(spawn_wave);

                if (enemies_list[0].x_pos <= 40)
                {
                    // enemy_shoot(en_i);
                    enemies_list[en_i].current_speed_x = 0;
                }
            }
            // if (type_4_5_flag)
            // {
                enemy_shoot(en_i);
            // }

            if (enemies_list.length < 4)
            {
                if (enemies_list[en_i].y_pos >= 55) 
                {
                    if (enemies_list[en_i].x_pos <= 0) 
                    {
                        enemies_list[en_i].current_speed_x = 2;
                        enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                    }

                    if (enemies_list[en_i].x_pos >= 455) 
                    {
                        enemies_list[en_i].current_speed_x = -2;
                        enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                    }
                }
            }
            break;
        case 6:
            enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
            enemies_list[en_i].y_speed = enemies_list[en_i].current_speed_y;

            if (enemies_list[en_i].y_pos >= 60 && enemies_list[en_i].y_pos < 70 && enemies_list[en_i].health >= 6500 && !health_check_1)
            {
                enemies_list[en_i].y_pos += 5;
                enemies_list[en_i].current_speed_y = 0;
            }

            enemy_shoot(en_i);

            if (enemies_list[en_i].health < 6500 && enemies_list[en_i].health >= 6000 && !health_check_1)
            {
                enemies_list[en_i].current_speed_x = -1;
                enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                health_check_1 = true;
            }

            if (health_check_1)
            {
                // enemy_shoot(en_i);
                if (enemies_list[en_i].x_pos > 0 && enemies_list[en_i].x_pos < 405) {
                    enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                }

                if (enemies_list[en_i].x_pos <= 0) {
                    enemies_list[en_i].current_speed_x = 1;
                    enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                    enemies_list[en_i].y_speed = enemies_list[en_i].current_speed_y;
                }

                if (enemies_list[en_i].x_pos >= 405) {
                    enemies_list[en_i].current_speed_x = -1;
                    enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                    enemies_list[en_i].y_speed = enemies_list[en_i].current_speed_y;
                }
                health_check_2 = true;
            }

            if (health_check_2 && enemies_list[en_i].health < 4000)
            {
                if (enemies_list[en_i].x_pos <= 202)
                {
                    enemies_list[en_i].current_speed_x = 0;
                    enemies_list[en_i].x_speed = enemies_list[en_i].current_speed_x;
                }
            }
    }
}

function enemy_shoot(en_i)
{
    if (enemies_list[en_i].can_fire && !enemies_list[en_i].boss)
    {
        enemies_list[en_i].can_fire = false;

        setTimeout(function()
        {
            enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 5, enemies_list[en_i].y_pos + 10, img_enemy_lazer, 0, 10);
            enemy_projectiles_list.push(enemy_projectile);

            // Play sound
            let enemy_shoot_sound = new create_sound("gun5.wav");
            enemy_shoot_sound.play();

            if (enemies_list[en_i].rapid_fire)
            {
                setTimeout(function() 
                {
                    enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 5, enemies_list[en_i].y_pos + 10, img_enemy_lazer, 0, 10);
                    enemy_projectiles_list.push(enemy_projectile);

                    // Play sound
                    let enemy_shoot_sound = new create_sound("gun5.wav");
                    enemy_shoot_sound.play();

                    setTimeout(function() 
                    {
                        enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 5, enemies_list[en_i].y_pos + 10, img_enemy_lazer, 0, 10);
                        enemy_projectiles_list.push(enemy_projectile);

                        // Play sound
                        let enemy_shoot_sound = new create_sound("gun5.wav");
                        enemy_shoot_sound.play();

                    }, enemies_list[en_i].multi_rate);
                }, enemies_list[en_i].multi_rate);
            }

            // console.log(enemy_projectiles_list);

            enemies_list[en_i].can_fire = true;
        }, enemies_list[en_i].fire_rate);
    }
    if (enemies_list[en_i].can_fire && enemies_list[en_i].boss)
    {
        enemies_list[en_i].can_fire = false;

        console.log(special_counter);

        if (shot_counter >= 18 && enemies_list[en_i].rapid_fire)
        {
            enemies_list[en_i].rapid_fire = false;
            shot_counter = 0;
            enemies_list[en_i].alternate_fire = true;
        }

        if (shot_counter >= 20 && enemies_list[en_i].alternate_fire)
        {
            enemies_list[en_i].alternate_fire = false;
            shot_counter = 0;
            enemies_list[en_i].rapid_fire = true;
        }

        setTimeout(function()
        {
            if (enemies_list[en_i].rapid_fire)
            {
                enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_boss_lazer, 0, 10);
                enemy_projectiles_list.push(enemy_projectile);

                shot_counter++;
            }

            // Play sound
            let enemy_shoot_sound = new create_sound("gun5.wav");
            enemy_shoot_sound.play();

            if (enemies_list[en_i].rapid_fire)
            {
                setTimeout(function() 
                {
                    enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_boss_lazer, 2, 10);
                    enemy_projectiles_list.push(enemy_projectile);

                    shot_counter++;

                    enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_boss_lazer, -2, 10);
                    enemy_projectiles_list.push(enemy_projectile);

                    shot_counter++;

                    // Play sound
                    let enemy_shoot_sound = new create_sound("gun5.wav");
                    enemy_shoot_sound.play();

                    setTimeout(function() 
                    {
                        enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_boss_lazer, 1, 10);
                        enemy_projectiles_list.push(enemy_projectile);

                        shot_counter++;

                        enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_boss_lazer, -1, 10);
                        enemy_projectiles_list.push(enemy_projectile);

                        shot_counter++;

                        enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_boss_lazer, 0, 10);
                        enemy_projectiles_list.push(enemy_projectile);

                        shot_counter++;

                        // Play sound
                        let enemy_shoot_sound = new create_sound("gun5.wav");
                        enemy_shoot_sound.play();

                    }, enemies_list[en_i].multi_rate);
                }, enemies_list[en_i].multi_rate);
            }

            if (enemies_list[en_i].alternate_fire)
            {
                setTimeout(function() 
                {
                    enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_special_lazer, 0, 20);
                    enemy_projectiles_list.push(enemy_projectile);

                    shot_counter++;

                    enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_special_lazer, 1, 20);
                    enemy_projectiles_list.push(enemy_projectile);

                    shot_counter++;

                    enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_special_lazer, -1, 20);
                    enemy_projectiles_list.push(enemy_projectile);

                    shot_counter++;

                    enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_special_lazer, 2, 20);
                    enemy_projectiles_list.push(enemy_projectile);

                    shot_counter++;

                    enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_special_lazer, -2, 20);
                    enemy_projectiles_list.push(enemy_projectile);

                    shot_counter++;

                    // Play sound
                    let enemy_alternate_fire_sound = new create_sound("cannon.wav");
                    enemy_alternate_fire_sound.play();

                    setTimeout(function() 
                    {
                        enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_special_lazer, 1, 20);
                        enemy_projectiles_list.push(enemy_projectile);

                        shot_counter++;

                        enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_special_lazer, -1, 20);
                        enemy_projectiles_list.push(enemy_projectile);

                        shot_counter++;

                        enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_special_lazer, 0, 20);
                        enemy_projectiles_list.push(enemy_projectile);

                        shot_counter++;

                        enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_special_lazer, 2, 20);
                        enemy_projectiles_list.push(enemy_projectile);

                        shot_counter++;

                        enemy_projectile = new create_projectile(8, 32, enemies_list[en_i].x_pos + (enemies_list[en_i].width / 2) - 2.5, enemies_list[en_i].y_pos + 40, img_special_lazer, -2, 20);
                        enemy_projectiles_list.push(enemy_projectile);

                        shot_counter++;

                        // Play sound
                        enemy_alternate_fire_sound.play();

                    }, enemies_list[en_i].multi_rate);
                }, enemies_list[en_i].multi_rate);
            }

            // console.log(enemy_projectiles_list);

            enemies_list[en_i].can_fire = true;
        }, enemies_list[en_i].fire_rate);
    }
}

function check_bounds()
{   
    for (let i = 0; i < players_list.length; i++)
    {
        if (players_list[i].x_pos + 50 <= 0)
            players_list[i].x_pos = 480;
        if (players_list[i].x_pos >= 500)
            players_list[i].x_pos = 0;
        if (players_list[i].y_pos + 10 == 0)
            players_list[i].y_pos = 0;
        if (players_list[i].y_pos == 810)
            players_list[i].y_pos = 800;
    }
}

function player_collision(play_i)
{
    for (let en_i = 0; en_i < enemies_list.length; en_i++)
    { 
        if ((players_list[play_i].y_pos <= enemies_list[en_i].y_pos) && (players_list[play_i].x_pos >= enemies_list[en_i].x_pos && players_list[play_i].x_pos <= enemies_list[en_i].x_pos + enemies_list[en_i].width))
        {
            players_list.splice(0, 1);
            play_i--;
            console.log(players_list);

            collision_explosion = new create_explosion(60, 63, enemies_list[en_i].x_pos, enemies_list[en_i].y_pos - 10, img_explosion, 1);
            explosion_list.push(collision_explosion);

            // Play sound
            let explosion_sound = new create_sound("explosion.wav");
            explosion_sound.play();

            console.log("created " + explosion_list);

            enemies_list.splice(en_i, 1);
            console.log(enemies_list);
            en_i--;

            player_death();

            return true;
        }   
    }
    return false;
}

function projectile_collision(proj_i)
{
    if (projectiles_list[proj_i].y_pos <= -10)
    {
        projectiles_list.splice(proj_i, 1);
        proj_i--;
        console.log("projectile out");
        console.log(projectiles_list);
        return true;
    }
    else 
    {
        return false;
    }
}

function hit_enemy(proj_i)
{
    for (let en_i = 0; en_i < enemies_list.length; en_i++)
    {
        if (enemies_list[en_i].y_pos >= projectiles_list[proj_i].y_pos && (projectiles_list[proj_i].x_pos + 10 >= enemies_list[en_i].x_pos && projectiles_list[proj_i].x_pos <= enemies_list[en_i].x_pos + enemies_list[en_i].width))
        {
            enemies_list[en_i].health -= projectiles_list[proj_i].damage;

            // Play sound
            let hit_sound = new create_sound("switch2.wav");
            hit_sound.play();

            console.log(enemies_list[en_i] + "'s health is " + enemies_list[en_i].health);

            projectiles_list.splice(proj_i, 1);
            proj_i--;

            if (enemies_list[en_i].health <= 0)
            {
                collision_explosion = new create_explosion(60, 63, enemies_list[en_i].x_pos, enemies_list[en_i].y_pos - 10, img_explosion, 1);
                explosion_list.push(collision_explosion);

                // Play sound
                let explosion_sound = new create_sound("explosion.wav");
                explosion_sound.play();

                console.log("created " + explosion_list);

                enemies_list.splice(en_i, 1);
                en_i--;
                console.log(enemies_list);
            }
        }
    }
}

function hit_shield(en_proj_i)
{
    for (let shield_i = 0; shield_i < shield_list.length; shield_i++)
    {
        if (shield_list[shield_i].y_pos <= enemy_projectiles_list[en_proj_i].y_pos && (enemy_projectiles_list[en_proj_i].x_pos + 10 >= shield_list[shield_i].x_pos && enemy_projectiles_list[en_proj_i].x_pos <= shield_list[shield_i].x_pos + shield_list[shield_i].width) && shield_list[shield_i].visible)
        {
            shield_list[0].health -= enemy_projectiles_list[en_proj_i].damage;

            // Play sound
            let hit_sound = new create_sound("switch2.wav");
            hit_sound.play();

            console.log(shield_list[shield_i] + "'s health is " + shield_list[shield_i].health);

            enemy_projectiles_list.splice(en_proj_i, 1);
            en_proj_i--;

            if (shield_list[shield_i].health <= 0) 
            {
                collision_explosion = new create_explosion(60, 63, shield_list[shield_i].x_pos, shield_list[shield_i].y_pos - 10, img_explosion, 1);
                explosion_list.push(collision_explosion);

                // Play sound
                let explosion_sound = new create_sound("explosion.wav");
                explosion_sound.play();

                console.log("created " + explosion_list);

                shield_list.splice(shield_i, 1);
                shield_i--;
                players_list[0].shield = false;
                console.log(players_list);
            }
        }
    }
}

function hit_player(en_proj_i)
{
    for (let play_i = 0; play_i < players_list.length; play_i++)
    {
        if (players_list[play_i].y_pos <= enemy_projectiles_list[en_proj_i].y_pos && (enemy_projectiles_list[en_proj_i].x_pos + 10 >= players_list[play_i].x_pos && enemy_projectiles_list[en_proj_i].x_pos <= players_list[play_i].x_pos + players_list[play_i].width))
        {
            players_list[play_i].health -= enemy_projectiles_list[en_proj_i].damage;

            // Play sound
            let hit_sound = new create_sound("switch2.wav");
            hit_sound.play();

            console.log(players_list[play_i] + "'s health is " + players_list[play_i].health);

            enemy_projectiles_list.splice(en_proj_i, 1);
            en_proj_i--;

            if (players_list[play_i].health <= 0)
            {
                collision_explosion = new create_explosion(60, 63, players_list[play_i].x_pos, players_list[play_i].y_pos - 10, img_explosion, 1);
                explosion_list.push(collision_explosion);

                // Play sound
                let explosion_sound = new create_sound("explosion.wav");
                explosion_sound.play();

                console.log("created " + explosion_list);

                players_list.splice(play_i, 1);
                play_i--;
                console.log(players_list);

                player_death();
            }
        }
    }
}

function explosion_bounds(ex_i)
{
    if (explosion_list[ex_i].distance_tracker == 15)
    {
        explosion_list.splice(ex_i, 1);
        ex_i--;
        console.log("destroyed " + explosion_list);
        return true;
    }
    else
    {
        return false;
    }
}

function enemy_projectile_collision(en_i)
{
    if (enemy_projectiles_list[en_i].y_pos >= 850)
    {
        enemy_projectiles_list.splice(en_i, 1);
        en_i--;
        // console.log(enemy_projectiles_list);
        return true;
    }
    else
    {
        return false;
    }
}

function player_death() 
{
    setTimeout(function() 
    {
        canvas_surface.stop_canvas();
        let retrieve_element = document.getElementById("canvas-container");
        retrieve_element.parentNode.removeChild(retrieve_element);
        popup_gameover.style.display = "block";
        
        // Play sound
        let gameover_sound = new create_sound("computer2.wav");
        gameover_sound.play();

        popup_dev_name.style.display = "none";
    }, 1200);
}

/***////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////***/